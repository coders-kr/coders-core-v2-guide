"""일반 HTTP 경로·브라우저 기능·리소스 파일 저장을 함께 사용하는 예제."""

import os
import uuid

import httpx
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, Response
from pydantic import BaseModel, Field

app = FastAPI()


@app.get("/health")
def health():
    return {"status": "ready"}


@app.get("/worker.js")
def worker():
    return Response(
        "onmessage = () => postMessage('Worker 준비 완료');", media_type="text/javascript"
    )


@app.get("/")
def index():
    return HTMLResponse("""<!doctype html><html lang="ko"><head><meta charset="utf-8">
<title>HTTP 웹앱</title></head><body>
<h1>HTTP 웹앱 · 파일 저장</h1><p id="status">브라우저 기능 확인 중</p>
<input type="file" id="file"><button id="upload">파일 저장</button><pre id="result"></pre>
<script>
const worker = new Worker('/worker.js');
worker.onmessage = e => {
  new WebAssembly.Module(new Uint8Array([0,97,115,109,1,0,0,0]));
  document.querySelector('#status').textContent = e.data + ' · WASM 준비 완료';
};
worker.postMessage({});
document.querySelector('#upload').onclick = async () => {
  const file = document.querySelector('#file').files[0];
  if (!file) return;
  const result = document.querySelector('#result');
  try {
    const prepared = await fetch('/api/uploads', {method:'POST',
      headers:{'Content-Type':'application/json'}, body:JSON.stringify({size:file.size})});
    const link = await prepared.json();
    if (!prepared.ok) throw new Error(link.error?.message || '전송 링크 발급 실패');
    const sent = await fetch(link.url, {method:'PUT', headers:{'Content-Type':file.type ||
      'application/octet-stream'}, body:file});
    if (!sent.ok) throw new Error('파일 저장 실패: ' + sent.status);
    result.textContent = '저장 완료: ' + link.key;
  } catch (error) { result.textContent = error.message; }
};
</script></body></html>""")


class Upload(BaseModel):
    size: int = Field(ge=0, le=536870912)


@app.post("/api/uploads")
async def upload(body: Upload, request: Request):
    # 신원은 Core가 검증한 헤더이며, 파일은 현재 워크스페이스에 귀속됩니다.
    key = "uploads/" + uuid.uuid4().hex
    async with httpx.AsyncClient(base_url=os.environ["CODERS_URL"], timeout=15) as core:
        response = await core.post(
            "/v1/objects/links",
            json={
                "key": key,
                "method": "PUT",
                "size": body.size,
            },
        )
    return (
        Response(
            response.content,
            response.status_code,
            media_type="application/json",
            headers={"X-Workspace": request.headers.get("coders-resource-id", "")},
        )
        if not response.is_success
        else {**response.json(), "key": key}
    )
