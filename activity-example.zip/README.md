# 공동 편집과 Agent 활동 예제

브라우저와 CLI가 같은 PostgreSQL 문서를 조회·수정합니다.
저장이 완료되면 Core 활동을 발행하고, 열린 브라우저가 데이터를 재조회해 해당 문서를 강조합니다.

이 디렉터리의 내용을 공개 저장소 루트에 두고 GitHub Actions로 HTTP 이미지를 빌드합니다.
Coders에서 커밋을 준비한 뒤 워크스페이스를 만들고 PostgreSQL과 프론트 권한을 승인합니다.
`DATABASE_URL`과 `CODERS_URL`은 기존 Coders HTTP 실행 환경에서 제공됩니다.

```bash
export CODERS_APP_URL='https://api.coders.kr/OWNER/REPO/FULL_COMMIT_SHA'
export CODERS_GRANT='<existing-account-key>'
export CODERS_RESOURCE='<workspace-id>'
python agent.py state
python agent.py save 'Agent가 수정한 제목' --action-id 3f7ddf99-c9b5-434a-9ff2-d479fc180aa8
python agent.py watch
```

브라우저와 CLI는 `state`와 `save`라는 동일한 앱 API를 사용합니다.
상태 응답에는 문서와 실행 가능한 동작의 설명이 포함됩니다.
`watch`는 처음 연결하거나 이력을 놓치면 데이터를 다시 조회하고, 이후 활동을 JSON 줄로 출력합니다.

`save`는 `action_id`로 DB 변경을 멱등 처리합니다.
응답이 불명확하면 같은 행동 ID와 요청 ID로 결과를 확인합니다.
`saved=true, activity_pending=true`는 DB 저장이 끝나고 알림 발행이 남았다는 뜻입니다.
이때 같은 행동 ID·입력에 새로운 `--request-id`를 지정하면 저장을 유지한 채 알림을 재시도합니다.
각 HTTP 호출에는 기존 Coders 요금이 적용됩니다.

Core의 `actor`는 인증된 실행 정보를 나타내며, `actor_label`은 앱의 표시 이름입니다.
공유 서버의 알림은 특정 사용자가 아닌 앱의 보고로 표시됩니다.
